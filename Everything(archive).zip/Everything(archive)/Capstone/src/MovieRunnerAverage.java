import java.util.ArrayList;
import java.util.Collections;


public class MovieRunnerAverage {
    public static void printAverageRatings(){
    	//SecondRatings sr = new SecondRatings();
    	SecondRatings sr = new SecondRatings("data/ratedmoviesfull.csv", "data/ratings.csv");
    	System.out.println("Movies: " + sr.getMovieSize() + "\t" + "Ratings: " + sr.getRaterSize());
        ArrayList<Rating> list = sr.getAverageRatings(12);
        //Collections.sort(list,Collections.reverseOrder());
        Collections.sort(list);
        for(Rating r:list){
        	System.out.println(r.getValue() + "\t" + sr.getTitle(r.getItem()));
        }
        System.out.println(list.size());
    }
    public static void getAverageRatingOneMovie(){
    	//SecondRatings sr = new SecondRatings();
    	SecondRatings sr = new SecondRatings("data/ratedmoviesfull.csv", "data/ratings.csv");
    	System.out.println("Movies: " + sr.getMovieSize() + "\t" + "Ratings: " + sr.getRaterSize());
    	String movieTitle = "Vacation";
    	String id = sr.getID(movieTitle);
    	System.out.println(movieTitle + "\t" + sr.getAverageByID(id, 0));
    	
    }
    /*public static void main(String[] args){
    	printAverageRatings();
    	//getAverageRatingOneMovie();
    }*/
}
