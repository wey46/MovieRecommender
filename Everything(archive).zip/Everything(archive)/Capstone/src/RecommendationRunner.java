import java.util.ArrayList;


public class RecommendationRunner implements Recommender {
	public ArrayList<String> getItemsToRate (){
		RaterDatabase.initialize("ratings.csv");
		ArrayList<String> ans = new ArrayList<String>();
		int i=0;
		for(String id:RaterDatabase.getRater("65").getItemsRated()){
			ans.add(id);
			i++;
			if(i==10) break;
		}
		return ans;
	}
	public void printRecommendationsFor (String webRaterID){
		RaterDatabase.initialize("ratings.csv");
    	MovieDatabase.initialize("ratedmoviesfull.csv");
    	FourthRatings fr = new FourthRatings();
    	ArrayList<Rating> list = fr.getSimilarRatings(webRaterID, 10, 3);
    	for(int i=0;i<10;i++){
        	Rating r = list.get(i);
        	System.out.println(r.getValue() + "\t" + MovieDatabase.getTitle(r.getItem())+"<br>");
        }	
	}
}
