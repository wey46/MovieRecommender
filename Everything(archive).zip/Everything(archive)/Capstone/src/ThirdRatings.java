import java.util.ArrayList;


public class ThirdRatings {
    private ArrayList<Rater> myRaters;
    
    public ThirdRatings() {
    	this("data/ratings_short.csv");
    }
    public ThirdRatings(String ratingfile){
    	myRaters = FirstRatings.loadRaters("data/"+ratingfile);
    }
   
    public int getRaterSize(){
    	return myRaters.size();
    }
    
    
    public double getAverageByID(String Mvid, int minRt){
    		double totalRatings = 0.0;
    		int totalRaters = 0;
    		for (Rater rtr : myRaters){
    			if(rtr.hasRating(Mvid)){
    				totalRaters ++;
    				totalRatings += rtr.getRating(Mvid);
    			}
    		}
    		if (totalRaters<minRt){
    			//System.out.println("no enough ratings: " + totalRaters);
    			return 0.0; //return 0.0 for not enough ratings
    		} else {
    			return totalRatings/totalRaters; //else return average
    		}
    }
    
    public ArrayList<Rating> getAverageRatings(int minRtr){
    	ArrayList<String> movies = MovieDatabase.filterBy(new TrueFilter());
        ArrayList<Rating> ans = new ArrayList<Rating>();
    	for (String movieid : movies){
        	double avgrating = getAverageByID(movieid,minRtr);
        	if(avgrating != 0.0){
        		Rating newRt = new Rating(movieid,avgrating);
        		ans.add(newRt);
        	}
        }
    	return ans;
    }
    
    public ArrayList<Rating> getAverageRatingsByFilter(int minRtr, Filter criteria){
    	ArrayList<String> movies = MovieDatabase.filterBy(criteria);
    	ArrayList<Rating> ans = new ArrayList<Rating>();
    	for (String movieid : movies){
        	double avgrating = getAverageByID(movieid,minRtr);
        	if(avgrating != 0.0){
        		Rating newRt = new Rating(movieid,avgrating);
        		ans.add(newRt);
        	}
        }
    	return ans;
    }
    
    
}
