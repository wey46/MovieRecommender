
/**
 * Write a description of SecondRatings here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.*;

public class SecondRatings {
    private ArrayList<Movie> myMovies;
    private ArrayList<Rater> myRaters;
    private ArrayList<String> MoviesIDs;
    
    public SecondRatings() {
        //this("ratedmoviesfull.csv", "ratings.csv");
    	this("data/ratedmovies_short.csv", "data/ratings_short.csv");
    }
    public SecondRatings(String moviefile, String ratingfile){
    	//new FirstRatings();
    	myMovies = FirstRatings.loadMovies(moviefile);
    	myRaters = FirstRatings.loadRaters(ratingfile);
    	getMovieIDs();
    }
    public int getMovieSize(){
    	return myMovies.size();
    }
    public int getRaterSize(){
    	return myRaters.size();
    }
    
    

    private void getMovieIDs(){
        MoviesIDs = new ArrayList<String>();
    	for(Movie mv: myMovies){
    		MoviesIDs.add(mv.getID());
    	}
    }
    
    public double getAverageByID(String Mvid, int minRt){
    	//get a list of mymovies id
    	getMovieIDs(); 	
    	if (!MoviesIDs.contains(Mvid)) return -1.0; //-1.0 movie id does not exist
    	else {
    		double totalRatings = 0.0;
    		int totalRaters = 0;
    		for (Rater rtr : myRaters){
    			if(rtr.hasRating(Mvid)){
    				totalRaters ++;
    				totalRatings += rtr.getRating(Mvid);
    			}
    		}
    		if (totalRaters<minRt){
    			//System.out.println("no enough ratings: " + totalRaters);
    			return 0.0; //return 0.0 for not enough ratings
    		} else {
    			return totalRatings/totalRaters; //else return average
    		}
    	}
    }
    
    public ArrayList<Rating> getAverageRatings(int minRtr){
        ArrayList<Rating> ans = new ArrayList<Rating>();
    	for (String movieid : MoviesIDs){
        	double avgrating = getAverageByID(movieid,minRtr);
        	if(avgrating != 0.0){
        		Rating newRt = new Rating(movieid,avgrating);
        		ans.add(newRt);
        	}
        }
    	return ans;
    }
    
    public String getTitle(String movieID){
    	for(Movie m:myMovies){
    		if (m.getID().equals(movieID)) return m.getTitle();
    	}
    	return "Err404,no such ID";
    }
    public String getID(String movieTitle){
    	for(Movie m:myMovies){
    		if (m.getTitle().equals(movieTitle)) return m.getID();
    	}
    	return "Err404, no such Title";
    }
    
    
    
}
