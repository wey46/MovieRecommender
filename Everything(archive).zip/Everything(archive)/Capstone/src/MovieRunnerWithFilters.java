import java.util.ArrayList;
import java.util.Collections;


public class MovieRunnerWithFilters {

	public static void main(String[] args) {
		printAverageRatingsByFilter();
		//printAverageRatings();
	}
	public static void printAverageRatings(){
    	//SecondRatings sr = new SecondRatings();
    	ThirdRatings tr = new ThirdRatings("ratings.csv");
    	MovieDatabase.initialize("ratedmoviesfull.csv");
    	System.out.println("Movies: " + MovieDatabase.size() + "\t" + "Ratings: " + tr.getRaterSize());
        ArrayList<Rating> list = tr.getAverageRatings(35);
        //Collections.sort(list,Collections.reverseOrder());
        Collections.sort(list);
        for(Rating r:list){
        	System.out.println(r.getValue() + "\t" + MovieDatabase.getTitle(r.getItem()));
        }
        System.out.println("Found "+list.size()+" movies");
    }
	
	public static void printAverageRatingsByFilter(){
		ThirdRatings tr = new ThirdRatings("ratings.csv");
    	MovieDatabase.initialize("ratedmoviesfull.csv");
    	System.out.println("Movies: " + MovieDatabase.size() + "\t" + "Ratings: " + tr.getRaterSize());
        //ArrayList<Rating> list = tr.getAverageRatingsByFilter(1, new YearAfterFilter(2000));
        //ArrayList<Rating> list = tr.getAverageRatingsByFilter(1, new GenreFilter("Crime"));
        //ArrayList<Rating> list = tr.getAverageRatingsByFilter(1, new MinutesFilter(110,170));
        //ArrayList<Rating> list = tr.getAverageRatingsByFilter(1, new DirectorsFilter("Charles Chaplin,Michael Mann,Spike Jonze"));
    	AllFilters comb = new AllFilters();
    	//comb.addFilter(new YearAfterFilter(1990));
    	//comb.addFilter(new GenreFilter("Drama"));
    	comb.addFilter(new MinutesFilter(90,180));
    	comb.addFilter(new DirectorsFilter("Clint Eastwood,Joel Coen,Tim Burton,Ron Howard,Nora Ephron,Sydney Pollack"));
    	ArrayList<Rating> list = tr.getAverageRatingsByFilter(3, comb);
        //Collections.sort(list,Collections.reverseOrder());
        Collections.sort(list);
        for(Rating r:list){
        	//System.out.println(r.getValue() + "\t" + MovieDatabase.getTitle(r.getItem()));
        	//System.out.println("\t"+MovieDatabase.getGenres(r.getItem()));
        	System.out.println(r.getValue()+"\t"+MovieDatabase.getTitle(r.getItem())+"\t"+MovieDatabase.getMovie(r.getItem()));
        	System.out.println("\t"+MovieDatabase.getDirector(r.getItem())+"\t"+MovieDatabase.getMinutes(r.getItem()));
        }
        System.out.println("Found "+list.size()+" movies");
	}

}
