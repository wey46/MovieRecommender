import java.util.*;
import org.apache.commons.csv.*;
import edu.duke.*;
public class FirstRatings {
    public static ArrayList<Movie> loadMovies(String movieFile){
    	ArrayList<Movie> movies = new ArrayList<Movie>();
    	FileResource fr = new FileResource(movieFile);
        for (CSVRecord csv : fr.getCSVParser()){
        	int minutes = Integer.parseInt(csv.get("minutes"));
        	Movie movie = new Movie(csv.get("id"), csv.get("title"), csv.get("year"), csv.get("genre"),
        			                csv.get("director"), csv.get("country"), csv.get("poster"), minutes);
        	movies.add(movie);
        }
    	return movies;
    }
    
    
    public static ArrayList<Rater> loadRaters(String ratingFile){
    	ArrayList<Rater> raters = new ArrayList<Rater>();
    	FileResource fr = new FileResource(ratingFile);
    	String processing = "";
        for (CSVRecord csv : fr.getCSVParser()){
        	String id = csv.get("rater_id");
        	if(!id.equals(processing)){ //new rater
        		processing = id; 
        		Rater rater = new EfficientRater(id); //create new rater with id
        		double rating = Double.parseDouble(csv.get("rating"));
        		rater.addRating(csv.get("movie_id"), rating); //add rating
        		raters.add(rater); //add rater in the raters
        	} else { //processing rater
        		double rating = Double.parseDouble(csv.get("rating"));
        		int currentIdx = raters.size()-1; //the last in the raters id the current
        		Rater rater = raters.remove(currentIdx); //remove rater
        		rater.addRating(csv.get("movie_id"), rating); // update rater
        		raters.add(rater); //add it back
        	}        	
        }
    	return raters;
    }
    
    /*private static void testLoadRater(){
    	ArrayList<Rater> test = loadRaters();
    	System.out.println(test.size() + " raters added");
    	for (int i=0;i<test.size();i++){
    		System.out.println("ID: "+test.get(i).getID()+"\t"+"No. of ratings: "+test.get(i).numRatings());
    		ArrayList<String> rated = test.get(i).getItemsRated();
    		for(String s: rated){
    			System.out.println(s+": "+test.get(i).getRating(s));
    		}
        System.out.println("\n");
    	}
    	Scanner in = new Scanner(System.in);
    	System.out.println("input rater id for his rating: ");
    	if(in.hasNextInt()){
    		int raterid = in.nextInt();
    		for (Rater r : test ){
    			if(r.getID().equals(Integer.toString(raterid))){
    				System.out.println("id: " + r.getID() + " has " + r.numRatings() + " ratings");
    				break;
    			}
    		}
    	}
    	System.out.println("input movie id for its rating: ");
    	Scanner in2 = new Scanner(System.in);
    	if(in2.hasNextInt()){
    		int movieid = in2.nextInt();
    		String item = Integer.toString(movieid);
    		int howmany=0;
    		for (Rater r : test ){
    			if(r.hasRating(item)){
    				howmany++;
    			} else {}
    		}
    		System.out.println(movieid+" has "+howmany+" rater(s)");
    	}
    	Collections.sort(test, new compareRater());
    	int maxratings = test.get(test.size()-1).numRatings();
    	int iter = 0;
    	for(int k=test.size()-1;k>=0;k--){
    		if (test.get(k).numRatings()==maxratings){
    			iter++;
    		} else {
    			break;
    		}
    	}
    	System.out.println("max rater has "+maxratings+" ratings."+" there are(is) "+iter+" such rater(s)");
    	ArrayList<String> movieList = new ArrayList<String>();
    	for (Rater r2: test){
    		ArrayList<String> list = r2.getItemsRated();
    		for(String boo:list){
    			if (!movieList.contains(boo)) movieList.add(boo);
    		}
    	}
    	System.out.println("Total rated movies: "+movieList.size());
    }*/

        /*private static void testLoadMovies(){
	    ArrayList<Movie> test = loadMovies();
	    System.out.println(test.size() + " movies loaded");
	    ArrayList<Movie> comedy = new ArrayList<Movie>();
	    ArrayList<Movie> longMovie = new ArrayList<Movie>();
	    HashMap<String,Integer> dMap = new HashMap<String,Integer>();
	    ArrayList<String> bigdr = new ArrayList<String>();
	    for (int i=0; i<test.size();i++){
		    //System.out.println(i + " :" + test.get(i).getTitle());
		    Movie m = test.get(i);
		    if(m.getGenres().contains("Comedy")){
		    	comedy.add(m);
		    }
		    if(m.getMinutes() > 150){
		    	longMovie.add(m);
		    }
		    String[] director = m.getDirector().split(",");
		    for(int j=0;j<director.length;j++){
			    if(!dMap.containsKey(director[j])){
				    dMap.put(director[j], 1);
			    } else {
				    int temp = dMap.get(director[j]);
				    dMap.put(director[j], temp+1);
		    	}
		    }
	    }
	    System.out.println("Movies belong to comedy: " + comedy.size());
	    System.out.println("Movies longer than 150 mins: " + longMovie.size());
	    int maxDir = 0;
	    for (int value : dMap.values()){
		    if(value > maxDir){
			    maxDir = value;
		    }
	    }
	    for(String key: dMap.keySet()){
		    if (dMap.get(key) == maxDir){
			    bigdr.add(key);
		    }
	    }
	    System.out.println("max-movie-director directs "+maxDir+" movies");
	    System.out.println(bigdr.size());
	    System.out.println(bigdr);
    }*/
    
    public static void main(String[] args){
    	//testLoadMovies();
    	//testLoadRater();
    }
}
